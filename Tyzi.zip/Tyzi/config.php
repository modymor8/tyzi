<?php

$email = "mahmoudabassy611@gmail.com";
$passcode = "YC3Y9";
$device_id = "xxxxxxxxx";
$push_token = "xxxxxxxx";
